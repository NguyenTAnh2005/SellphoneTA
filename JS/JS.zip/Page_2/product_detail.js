import { loadHeaderFooter } from "../helper_function_all.js"
loadHeaderFooter("../");

// import { loadBreadcrumb } from "../helper_function_all.js"
// loadBreadcrumb("BREADCRUMB");
